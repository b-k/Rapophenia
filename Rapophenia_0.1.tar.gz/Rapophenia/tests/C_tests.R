library(Rapophenia)
.C("init_registry")
.C("test_Rapophenia")
